<?php
namespace Home\Controller;
use Think\Controller;
class IntelController extends Controller {

    public function index(){
    	
		$this->display();	
    }
	public function index1(){
    	
		$this->display();	
    }
    
    
}