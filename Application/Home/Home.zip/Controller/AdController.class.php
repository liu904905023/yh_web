<?php
namespace Home\Controller;
use Think\Controller;
class AdController extends Controller{

    public function ad()
	{
        $this->display();
    }
	
}
