<?php
namespace Home\Controller;
use Think\Controller;
class IntelController extends Controller {

    public function index(){
        $SystemUserSysNo = $_GET['systemUserSysNo'];

		$data =$this -> CheckType($SystemUserSysNo);

        if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ) {
            if($data['model'][0]["Customer_field_one"]==104||$data['model'][0]["Customer_field_one"]==106||$data['model'][0]["Customer_field_one"]==108){
                header( 'Location:http://web.yunlaohu.cn/index.php/Wft/newpay/?systemUserSysNo='.$SystemUserSysNo);
            }else{
                header( 'Location: http://'.$_SERVER['HTTP_HOST'].'/index.php/Wxpay/newpay/?systemUserSysNo='.$SystemUserSysNo);
            }
        }
        if ( strpos($_SERVER['HTTP_USER_AGENT'], 'AlipayClient') !== false ) {
            if($data['model'][0]["Customer_field_one"]==104||$data['model'][0]["Customer_field_one"]==106){
				$app_id = $this -> QueryAppId($SystemUserSysNo);
                header( 'Location:https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id='.$app_id.'&scope=auth_base&redirect_uri=http://'.$_SERVER['HTTP_HOST'].'/index.php/WftAli/index?systemUserSysNo='.$SystemUserSysNo);

            }else if ($data['model'][0]["Customer_field_one"]==108){
                $AliUrl = $this->GetAliUrl($SystemUserSysNo);
                header( 'Location:'.$AliUrl);

            }else{
				$app_id = $this -> QueryAppId($SystemUserSysNo);
                header( 'Location:https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id='.$app_id.'&scope=auth_base&redirect_uri=http://'.$_SERVER['HTTP_HOST'].'/index.php/Isv/index?systemUserSysNo='.$SystemUserSysNo);

            }
        }

    }

	private function CheckType($SystemUserSysNo){

		$customer = staffquerystore($SystemUserSysNo);

        $url  = C( 'SERVER_HOST' ) . "IPP3Customers/IPP3CustomerShopList";

        $arr  = array(
            "SysNo" => $customer
        );

        $data = json_encode( $arr );

        $head = array(
            "Content-Type:application/json;charset=UTF-8",
            "Content-length:" . strlen( $data )
        );

        $res  = http_request( $url, $data, $head );

        $data = json_decode( $res, TRUE );

		return $data;
	}
	private function QueryAppId($systemUserSysNo){

		$data['systemUserSysNo'] = $systemUserSysNo;

        $data = json_encode($data);

        $urls = C('SERVER_HOST') . "IPP3Customers/IPP3AliPayConfigBySUsysNo";

        $head = array("Content-Type:application/json;charset=UTF-8", "Content-length:" . strlen($data), "X-Ywkj-Authentication:" . strlen($data));

        $list = http_request($urls, $data, $head);

        $list = json_decode($list, true);

		return $list['AppID'];
	}
	private function GetAliUrl($systemUserSysNo){
        $data['SystemUserSysNo'] = $systemUserSysNo;

        $data = json_encode($data);

        $urls = C('SERVER_HOST') . "IPP3Customers/IPP3SystemUserExtendList";

        $head = array("Content-Type:application/json;charset=UTF-8", "Content-length:" . strlen($data), "X-Ywkj-Authentication:" . strlen($data));

        $list = http_request($urls, $data, $head);

        $list = json_decode($list, true);

        return $list['Ali_url'];
    }


}                                   